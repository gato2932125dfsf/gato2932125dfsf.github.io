/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.zonajava.semana02_actividad;

/**
 *
 * @author Pavilion
 */
public class Semana02_Actividad {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
